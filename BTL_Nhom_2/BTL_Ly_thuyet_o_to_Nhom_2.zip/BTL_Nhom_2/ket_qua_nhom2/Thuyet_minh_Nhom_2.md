## BÀI TẬP LỚN LÝ THUYẾT Ô TÔ — NHÓM 2

TRƯỜNG ĐẠI HỌC BÁCH KHOA — KHOA CƠ KHÍ GIAO THÔNG. Tính toán thiết kế sức kéo ô tô tải dùng động cơ diesel, truyền lực cơ khí. Họ tên, MSV và giáo viên hướng dẫn: điền theo danh sách lớp.

Bài tính thực hiện theo đề Nhóm 2 trong ảnh người dùng cung cấp. Giáo trình Nguyễn Hữu Cẩn và cộng sự, Lý thuyết ô tô máy kéo, bản in 2005 là tài liệu cơ sở; bài mẫu Nhóm 1 chỉ dùng để đối chiếu trình tự và số công thức. Các số liệu xe của bài mẫu không được coi là dữ liệu đề Nhóm 2.

## 1. Dữ liệu đề bài và giả thiết thiết kế

| Đại lượng | Giá trị | Phân loại |
| --- | --- | --- |
| Loại xe / truyền lực | Tải / cơ khí | Đề bài |
| Khối lượng bản thân | 3.450 kg | Đề bài |
| Tải hàng định mức | 4.100 kg | Đề bài |
| Số người, kể cả lái | 2 | Đề bài |
| Phân bố cầu trước / sau | 0,30 / 0,70 | Đề bài |
| Vận tốc cực đại yêu cầu | 95 km/h | Đề bài |
| Sức cản đường lớn nhất ψmax | 0,31 | Đề bài |
| Động cơ | Diesel | Đề bài |

Chữ [KG] của đề được hiểu là đơn vị khối lượng kg. Ký hiệu G trong công thức động lực học dưới đây luôn là trọng lực N, không thay trực tiếp số kg vào công thức lực. Giả thiết G0 chưa gồm 2 người; tải 4.100 kg là tải hàng. Nếu quy ước đề của giảng viên khác, cần sửa khối lượng tương ứng.

| Thông số tự chọn | Giá trị | Cơ sở / giới hạn |
| --- | --- | --- |
| Khối lượng mỗi người; g | 70 kg; 9,81 m/s² | Quy ước tính |
| Bố trí truyền động | 4×2, cầu sau chủ động; bánh sau kép | Đề chưa cho bố trí cầu |
| Hiệu suất tổng η | 0,89 | Giả định thiết kế, tương thích bài mẫu |
| K; diện tích A | 0,65 N·s²/m⁴; 4,5 m² | Giả định cản khí động; W=KA=2,925 |
| f0; φ | 0,015; 0,80 | Đường tốt, khô; hệ số bám tính theo tải tĩnh |
| Lốp dự chọn; λt | 8.25R16; 0,935 | Chỉ là chọn kích thước sơ bộ |
| Đặc tính diesel | a=0,5; b=1,5; c=1 | Giả thiết diesel 4 kỳ phun trực tiếp, sách tr.12 |
| nN; λv; nmin | 2.600 rpm; 0,90; 800 rpm | n_v=2.340 rpm, trong khoảng gợi ý sách tr.142 |
| Hộp số | 5 số tiến; số cao nhất =1; ip=1 | Sơ đồ thiết kế lựa chọn |
| Chuyển số | n=2.340 rpm; 1 giây/lần | Lịch cố định; chưa tối ưu thời gian |
| Quán tính | δh=1,05+0,05ih²; δcoast=1,05 | Kinh nghiệm sách; lúc chuyển số ngắt quán tính động cơ |

Không có kích thước bao xe, vị trí trọng tâm, thông số động cơ thực và bảng tải lốp nên đây là một phương án thiết kế tính toán có điều kiện. Không đồng nhất động cơ tương đương này với một mã động cơ thương mại.

## 2. Trọng lượng toàn bộ và tải trọng các cầu

> m = m0 + mh + nc·mn = 3450 + 4100 + 2×70 = 7690 kg

> G = m·g = 75.438,9 N; G1 = 0,30G = 22.631,67 N; G2 = 0,70G = 52.807,23 N

| Vị trí | Khối lượng tương đương | Trọng lực |
| --- | --- | --- |
| Toàn xe | 7.690 kg | 75.438,9 N |
| Cầu trước | 2.307 kg | 22.631,67 N |
| Cầu sau | 5.383 kg | 52.807,23 N |

Với hai bánh trước và bốn lốp sau, tải tĩnh bình quân mỗi lốp trước là 1.153,5 kg, mỗi lốp sau là 1.345,75 kg. Khi chọn sản phẩm phải kiểm tra tải cho lắp đơn/lắp kép, cấp tốc độ ít nhất 95 km/h, áp suất và dự trữ tải động. Chưa có catalogue nên không kết luận lốp dự chọn đã được chứng nhận đủ tải.

Nếu giảng viên quy ước g=10 m/s² như bài mẫu thì G=76.900 N, G1=23.070 N, G2=53.830 N. Không trộn các giá trị này vào bài đang dùng g=9,81; thay g trong tệp tham số và tính lại toàn bộ.

## 3. Bán kính bánh xe, cản lăn và cản không khí

> r0 = (B+d/2)·0,0254 = (8,25+16/2)·0,0254 = 0,41275 m; rb = λt·r0 = 0,385921 m

Công thức hình học dùng bề rộng danh nghĩa như chiều cao tiết diện, chỉ phù hợp cho chọn sơ bộ dạng lốp số inch cũ. Bán kính lăn phải được thay bằng thông số tải thực khi có catalogue; không đồng nhất bán kính tự do, tĩnh và lăn.

> f(v) = 0,015 nếu v≤22,2 m/s; f(v) = 0,015(1+v²/1500) nếu v>22,2 m/s

> Pf = f(v)G trên đường bằng; Pw = KAv² = 2,925v²; Pc = Pf+Pw

Giáo trình tr.53, (II-16), cho hệ số cản lăn tăng theo tốc độ ở vùng trên khoảng 80 km/h. Với đề 95 km/h, không giữ f=0,015 trong phép chọn công suất. Cách ghép hai miền theo sách có bước nhảy tại 22,2 m/s (79,92 km/h): f tăng từ 0,015 lên khoảng 0,0199284. Đây là hạn chế của xấp xỉ thực nghiệm, không phải một lực vật lý nhảy đột ngột. Bảng tích phân tách tại ngưỡng; đồ thị giữ bước nhảy để minh bạch giả thiết. Có dữ liệu lốp thực thì thay bằng hàm f(v) liên tục đã hiệu chỉnh.

> vmax = 95/3,6 = 26,388889 m/s; f(vmax) = 0,0219637

| Tại 95 km/h | Giá trị |
| --- | --- |
| Pf | 1.656,92 N |
| Pw | 2.036,89 N |
| Pc | 3.693,81 N |
| Công suất bánh xe Pc·v/1000 | 97,476 kW |

## 4. Công suất cần thiết và đặc tính ngoài động cơ

> Nv = [G·f(vmax)·vmax + K·A·vmax³]/(1000η)

> Nv = 109,523150 kW; λv = nv/nN = 0,9; nv = 2340 rpm

> Nmax = Nv/[aλv+bλv²−cλv³] = Nv/0,936

> Nmax = 117,011912 kW; Ne(n) = Nmax[0,5x+1,5x²−x³], x=n/2600

> Me(n) = 60000Ne/(2πn) = 9549,2966Ne/n (N·m)

Bài này dùng công suất thiết kế tối thiểu để đường cân bằng công suất ở số V khép kín tại đúng 95 km/h. Không nhân dự trữ rồi tiếp tục sử dụng đặc tính công suất cũ. Nếu cần chọn động cơ thương mại có dự trữ 10%, mức tham khảo là 128,71 kW (có thể xét cấp 130 kW), nhưng phải thay đặc tính thực và tính lại vận tốc cân bằng, tỷ số truyền và tăng tốc. Mức 130 kW không được dùng trong kết quả bên dưới. Phụ tải phụ kiện chưa được tách riêng ngoài η; khi dùng công suất catalogue cần xác định đó là công suất có ích nào.

> nM = b·nN/(2c) = 1.950 rpm; Memax = 456,622 N·m

| n (rpm) | Ne (kW) | Me (N·m) |
| --- | --- | --- |
| 800 | 31,210 | 372,545 |
| 1000 | 41,809 | 399,246 |
| 1200 | 52,887 | 420,862 |
| 1400 | 64,125 | 437,391 |
| 1600 | 75,203 | 448,834 |
| 1800 | 85,802 | 455,192 |
| 1950 | 93,244 | 456,622 |
| 2000 | 95,601 | 456,463 |
| 2200 | 104,283 | 452,649 |
| 2340 | 109,523 | 446,953 |
| 2600 | 117,012 | 429,762 |

Đỉnh mômen lấy bằng đạo hàm, không chọn cực đại từ vài điểm lấy mẫu. Đặc tính ở vùng sau nN chỉ minh họa đa thức thực nghiệm; không thay thế đặc tính điều tốc của động cơ thật. Công suất tại 2.340 rpm là Nv, còn công suất cực đại của đa thức xuất hiện tại 2.600 rpm.

![Hình 1. Đặc tính ngoài động cơ tương đương thiết kế.](hinh/01_dac_tinh_dong_co.png)

## 5. Tỷ số truyền lực chính và hộp số

> i0 = 2π·rb·nv/(60·ih5·vmax) = 3,583621; ih5=1

> ih1_min = ψmax·G·rb/(Memax·i0·η); ih1_max = φ·G2·rb/(Memax·i0·η)

> 6,1971 ≤ ih1 ≤ 11,1947; chọn ih1=7

Giới hạn dưới yêu cầu đủ lực khắc phục sức cản đường ở tốc độ thấp; giới hạn trên kiểm tra bám theo tải tĩnh cầu sau, φ=0,8. Hệ số 0,7 là tỷ lệ tải cầu chủ động, không phải hệ số chuyển tải động. Đề thiếu chiều dài cơ sở và tọa độ trọng tâm nên chưa tính chính xác phản lực cầu khi lên dốc/tăng tốc.

> q = (ih1/ih5)^(1/4) = 1,626577; ihk=ih1/q^(k−1); iR=1,2ih1=8,4

| Số | ih | δ | v tại 800 rpm (km/h) | v tại 2340 rpm (km/h) |
| --- | --- | --- | --- | --- |
| 1 | 7,000000 | 3,5000 | 4,640 | 13,571 |
| 2 | 4,303517 | 1,9760 | 7,547 | 22,075 |
| 3 | 2,645751 | 1,4000 | 12,276 | 35,907 |
| 4 | 1,626577 | 1,1823 | 19,967 | 58,405 |
| 5 | 1,000000 | 1,1000 | 32,479 | 95,000 |

> Pk1,max = 26.416,09 N; Pφ = φG2 = 42.245,78 N

> v tại Memax, số I = 11,310 km/h; Pψmax+Pw = 23.414,93 N

Số I đủ lực: dự trữ tại điểm mômen cực đại là 3.001,16 N; còn dự trữ bám 15.829,70 N. Số lùi có lực kéo cực đại xấp xỉ 31.699,30 N, vẫn nhỏ hơn giới hạn bám tĩnh. Kết quả này không phải kiểm tra bền răng, trục hay nhiệt ly hợp; các kiểm tra đó ngoài dữ liệu đề.

Tại điểm mômen cực đại số I, D=0,34978. Trên dốc và tốc độ thấp, giải D=f0·cosα+sinα cho khả năng vượt dốc xấp xỉ 35,63% theo giả thiết tải bám đủ. Đây là giá trị tại điểm kiểm tra, chưa tối ưu D theo tốc độ và chưa xét dịch chuyển phản lực do trọng tâm. ψmax=0,31 không có nghĩa là dốc đúng 31%; ψ đã gồm cản lăn.

## 6. Cân bằng lực, công suất, nhân tố động lực học và gia tốc

> Pk = Me·i0·ih·η/rb; v = 2π·n·rb/(60·i0·ih)

> Pk = Pf+Pi+Pw+Pj; Pf=fGcosα; Pi=Gsinα; Pw=KAv²; Pj=mδj

> Nk = ηNe = Pk·v/1000; Nc=(Pf+Pw)·v/1000 trên đường bằng

> D=(Pk−Pw)/G; Dφ=(Pφ−Pw)/G; δh=1,05+0,05ih²

> j = g[D−f(v)]/δh = [min(Pk,Pφ)−Pf−Pw]/(mδh), khi giới hạn bám được áp dụng

Trong bộ số liệu này, Pk ở cả năm số tiến nhỏ hơn Pφ nên không phải cắt lực kéo theo bám. Khi sửa tham số đến mức Pk>Pφ, mô hình gia tốc chỉ giới hạn lực truyền hữu ích bằng Pφ, tương ứng điều chỉnh mômen để tránh trượt; không mô phỏng quay trơn. Đồ thị Pk và D vẫn thể hiện yêu cầu lý thuyết từ động cơ và có đường giới hạn bám để đối chiếu.

Pk ở đây là lực kéo quy đổi từ mômen truyền đến bánh xe. Pf được tính một lần trong tổng cản toàn xe. Không lấy lực kéo ròng đã trừ cản lăn ở bánh chủ động rồi tiếp tục trừ toàn bộ Pf, vì sẽ đếm cản lăn hai lần. Phân tích tiếp xúc bánh mềm–đường mềm bằng hợp lực R và lực tiếp tuyến T thuộc mô hình tiếp xúc cục bộ; bài sức kéo toàn xe này dùng lực quy đổi với các tổn thất được hạch toán nhất quán.

![Hình 02. Cân bằng công suất. Các đường số thể hiện miền 800–2600 rpm; phần j<0 không dùng để tích phân tăng tốc.](hinh/02_power.png)

![Hình 03. Cân bằng lực kéo. Các đường số thể hiện miền 800–2600 rpm; phần j<0 không dùng để tích phân tăng tốc.](hinh/03_force.png)

![Hình 04. Nhân tố động lực học. Các đường số thể hiện miền 800–2600 rpm; phần j<0 không dùng để tích phân tăng tốc.](hinh/04_dynamic.png)

![Hình 05. Gia tốc theo tay số. Các đường số thể hiện miền 800–2600 rpm; phần j<0 không dùng để tích phân tăng tốc.](hinh/05_acc.png)

Tại 95 km/h, số V: Nk=97,4756 kW bằng Nf+Nw; Pk−Pc=0,00000000 N (sai số số học). Vì vậy j tiến về 0 tại vận tốc này. Phần đặc tính vượt 95 km/h có gia tốc âm và không phải vận tốc tự tăng tốc đạt được trên đường bằng.

## 7. Gia tốc ngược, thời gian và quãng đường tăng tốc

> t = ∫(1/j)dv; S = ∫(v/j)dv; dùng v m/s trong tích phân

> Δt ≈ 0,5(1/jA+1/jB)(vB−vA); ΔS ≈ 0,5(vA/jA+vB/jB)(vB−vA)

Bắt đầu ở nmin=800 rpm, số I: vmin=4,6398 km/h, đặt t=S=0 tại đó. Chưa tính giai đoạn xuất phát từ đứng yên với ly hợp trượt. Kết thúc ở 0,95vmax=90,25 km/h vì tích phân lý tưởng đến đúng điểm j=0 tại 95 km/h có thời gian phân kỳ. Kết quả không được ghi thành thời gian 0–95 km/h.

Chuyển số khi n=2.340 rpm, thời gian gián đoạn kéo 1 s mỗi lần, tổng 4 lần. Trong khoảng chuyển số, t và S vẫn tăng nhưng v giảm; vì vậy đường t(v), S(v) có đoạn quay nhẹ sang trái. Không nối trực tiếp hai số ở cùng một vận tốc rồi bỏ mất thời gian và quãng đường chuyển số. Lịch chuyển số này là phương án quy định, chưa chứng minh là nhanh nhất.

> Trong chuyển số: dv/dt = −[Gf(v)+KAv²]/(mδcoast); dS/dt=v; δcoast=1,05

| Pha | v đầu (km/h) | v cuối (km/h) | Δt (s) | ΔS (m) | n cuối/sau nối (rpm) |
| --- | --- | --- | --- | --- | --- |
| Kéo 1 | 4,640 | 13,571 | 2,792 | 6,953 | 2.340,0 |
| Chuyển số 1→2 | 13,571 | 13,049 | 1,000 | 3,697 | 1.383,2 |
| Kéo 2 | 13,049 | 22,075 | 2,566 | 12,508 | 2.340,0 |
| Chuyển số 2→3 | 22,075 | 21,523 | 1,000 | 6,055 | 1.402,6 |
| Kéo 3 | 21,523 | 35,907 | 5,030 | 40,120 | 2.340,0 |
| Chuyển số 3→4 | 35,907 | 35,275 | 1,000 | 9,886 | 1.413,3 |
| Kéo 4 | 35,275 | 58,405 | 13,180 | 172,098 | 2.340,0 |
| Chuyển số 4→5 | 58,405 | 57,562 | 1,000 | 16,106 | 1.417,8 |
| Kéo 5 | 57,562 | 90,250 | 81,329 | 1.781,371 | 2.223,0 |

> t(4,640 → 90,25 km/h) = 108,898 s; S = 2.048,794 m

![Hình 6. Gia tốc ngược của từng số, chỉ thể hiện phần j>0 và v≤90,25 km/h.](hinh/06_inverse.png)

![Hình 7. Thời gian tích lũy theo vận tốc; vùng màu nhạt là khoảng mất tốc độ khi chuyển số.](hinh/07_thoi_gian.png)

![Hình 8. Quãng đường tích lũy theo vận tốc, có tính quãng đường chuyển số.](hinh/08_quang_duong.png)

## 8. Kiểm tra kết quả và giới hạn áp dụng

| Phép kiểm | Kết quả |
| --- | --- |
| Khối lượng; tổng tải cầu | m=7690 kg; G1+G2=G |
| Công suất và lực kéo | max|Pk·v−1000ηNe|=7.28e-11 W |
| Điều kiện số I | 6,1971 < 7 < 11,1947; đã cộng Pw khi kiểm tra lại |
| Tích phân độc lập (quadrature) | t=108,896735 s; S=2.048,771638 m |
| Sai lệch hình thang so với quadrature | t: 0.000797%; S: 0.001113% |
| Tăng đôi mật độ điểm | Δt=-0.000653 s; ΔS=-0.017154 m |

Mô hình giả định đủ tải, đường bằng tốt cho đồ thị tăng tốc, không gió, không trượt dọc, bán kính lăn và hiệu suất không đổi. Cản dốc lớn nhất chỉ dùng chọn/kiểm tra số I; không dùng ψ=0,31 cho toàn bộ đồ thị tăng tốc đường bằng. Quán tính quay được xấp xỉ theo tỷ số truyền, chưa có mômen quán tính thực của động cơ, bánh đà và bánh xe.

Vận tốc 95 km/h, công suất và gia tốc là kết quả theo tham số đã chọn, không phải dữ liệu thử nghiệm của một xe thương mại. Thay diện tích cản, lốp, khối lượng mỗi người, hiệu suất hoặc đặc tính động cơ sẽ thay đổi kết quả. Chưa kiểm tra tải động cầu, bền hệ truyền lực, ổn định chống lật, phanh, nhiệt động cơ hoặc tiêu hao nhiên liệu; đề bài không cung cấp đủ dữ liệu cho các phần đó.

## 9. Đối chiếu công thức bài mẫu với giáo trình

Số trang dưới đây là số in trên trang: sách Nguyễn Hữu Cẩn có trang PDF = trang in +1; bài mẫu có trang PDF = trang in +7. Đây là các công thức được trích theo số hiệu của bài mẫu rồi chuẩn hóa ký hiệu và đơn vị, không phải sao chép nguyên mọi lỗi trình bày của bản mẫu.

Mẫu (2.1.1; tải cầu), tr.1; sách tr.136–138.

> m=m0+nc·mn+mh; G=mg; G1=β1G; G2=β2G

Tách kg và N; tải cầu ở trạng thái tĩnh.

Mẫu (2.2.1), tr.2; sách tr.139.

> Nv=[G·ψv·vmax+K·A·vmax³]/(1000η)

Nv kW; v m/s; ψv=f(vmax) trên đường bằng.

Mẫu (2.2.2), tr.3; sách tr.140, IV-49.

> Nmax=Nv/(aλ+bλ²−cλ³)

Công suất thiết kế cực đại, λ=nv/nN.

Mẫu (2.2.3), tr.3; sách tr.140 (cần phân biệt công suất sử dụng).

> Nchọn=kN·Nmax

Bài mẫu chọn kN=1,1–1,25; bài này kN=1 để khép kín vmax=95.

Mẫu (2.2.4), tr.3; sách tr.12, I-3.

> Me=60000·Ne/(2πn)

Ne kW, n rpm, Me N·m.

Mẫu (2.2.5), tr.3; sách tr.140–141.

> nv=λ·nN

Không coi λ là hằng số cho mọi điểm trên đặc tính.

Mẫu (2.2.6), tr.4; sách tr.11, I-2; 12.

> Ne=Nmax[a·x+b·x²−c·x³], x=n/nN

Diesel phun trực tiếp: a=0,5; b=1,5; c=1.

Mẫu (2.3.1 (i0)), tr.5; sách tr.141, IV-51.

> i0=2π·rb·nv/(60·ih_top·ip·vmax)

ip=1, truyền lực phụ không có.

Mẫu (2.3.1 (rb; mẫu trùng số)), tr.5; sách tr.37–38.

> r0=(B+d/2)·0,0254; rb=λt·r0

B,d inch; công thức hình học gần đúng cho lốp kiểu cũ.

Mẫu (2.3.2), tr.5; sách tr.35; 95–96; 127–128.

> Pψ+Pw+Pj ≤ Pk ≤ Pφ

Ở vận tốc thấp thường bỏ Pw khi chọn số I.

Mẫu (2.3.3), tr.6; sách tr.127–128.

> ih1 ≥ ψmax·G·rb/(Memax·i0·ip·η)

Sau chọn phải kiểm lại Pw ở điểm mômen lớn nhất.

Mẫu (2.3.4), tr.6; sách tr.127–128, IV-32.

> Pφ=φ·mZ·Gφ

mZ là hệ số thay đổi tải động; chọn 1 vì thiếu vị trí trọng tâm.

Mẫu (2.3.5), tr.6; sách tr.128, IV-33.

> ih1 ≤ φ·mZ·Gφ·rb/(Memax·i0·ip·η)

Gφ=G2 nếu cầu sau chủ động.

Mẫu (2.3.6), tr.7; sách tr.129–131.

> q=(ih1/ih_top)^(1/(z−1))

Cấp số nhân.

Mẫu (2.3.7), tr.7; sách tr.129–131.

> ihk=ih1/q^(k−1)

Số cao nhất chọn truyền thẳng.

Mẫu (2.3.8), tr.8; sách tr.142.

> iR=(1,2…1,3)ih1

Bài này chọn 1,2; kiểm tra bám số lùi.

Mẫu (3.1.1), tr.8; sách tr.88–89, IV-1…3.

> Ne=Nt+Nf+Nw+Ni+Nj

Quy ước dốc lên, tăng tốc, không gió.

Mẫu (3.1.2), tr.8; sách tr.89, IV-2.

> Nk=η·Ne

Tổn thất truyền lực đã tính trong η.

Mẫu (3.1.3), tr.9; sách tr.89; 95–96.

> Nc=Nf+Nw=(Gf+KA·v²)v/1000

Trên đường bằng; đơn vị kW.

Mẫu (3.2.1), tr.9; sách tr.95–96, IV-9…10.

> Pk=Pf+Pi+Pw+Pj

Pf=fGcosα; Pi=Gsinα; Pj=mδj.

Mẫu (3.2.2), tr.10; sách tr.16; 95–96.

> Pk=Me·i0·ih·ip·η/rb

Lực kéo tính từ mômen; không trừ Pf tại đây.

Mẫu (3.2.3), tr.11; sách tr.95–96.

> Pc=Pf+Pw=fG+KA·v²

Pc là tổng cản đường bằng, không riêng cản lăn.

Mẫu (3.3.1), tr.12; sách tr.101–102, IV-15…16.

> D=(Pk−Pw)/G=ψ+δj/g

D không có đơn vị.

Mẫu (3.3.2), tr.12; sách tr.35; 101–102 (suy ra).

> Dφ=(Pφ−Pw)/G

Cản không khí cũng phải trừ trong giới hạn Dφ.

Mẫu (3.3.3), tr.12; sách tr.35; 101–102 (suy ra).

> Dφ≥D≥ψ

Vùng đủ kéo, còn bám; D≥ψ tương ứng j≥0.

Mẫu (3.3.4), tr.12; sách tr.101–102.

> Dk=[Me·i0·ihk·η/rb−KA·v²]/G

Sửa ngoặc ở mẫu: toàn bộ hiệu chia G.

Mẫu (3.3.5), tr.12; sách tr.129–131.

> v=2π·n·rb/(60·i0·ih·ip)

v m/s; nhân 3,6 để đổi km/h.

Mẫu (3.4.1), tr.14; sách tr.102; 107–109.

> D=fcosα+sinα+δj/g ≈ f+i+δj/g

i=tanα; dạng xấp xỉ chỉ cho dốc nhỏ.

Mẫu (3.4.2), tr.14; sách tr.109, IV-23.

> j=g(D−ψ)/δ

Đường bằng ψ=f(v).

Mẫu (3.4.3), tr.14; sách tr.33–34, I-49…53.

> δ=1,05+0,05ih²

Công thức kinh nghiệm; có quán tính chi tiết thì dùng I-49.

Mẫu (3.5.1; 3.5.2), tr.18; sách tr.113–115, IV-24.

> dt=dv/j; t=∫dv/j

Bắt đầu ở vmin, không tự gán bắt đầu từ 0 km/h.

Mẫu (3.5.3; 3.5.4), tr.18; sách tr.117.

> dS=vdt; S=∫vdt=∫v·dv/j

Có thể tích phân trực tiếp v/j theo v.

Mẫu (3.5.5), tr.19; sách tr.116, IV-25.

> Δv≈ψ·g·t_shift/δcoast

Bài này tích phân thêm Pw trong khi ngắt mômen.

Mẫu (Hình thang (không số)), tr.18–19; sách tr.Số hóa tích phân IV-24.

> Δt≈0,5(1/jA+1/jB)Δv; ΔS≈0,5(vA/jA+vB/jB)Δv

Bản in mẫu có chỗ ghi chia 0,5; phải nhân 0,5.

Mẫu (Bổ sung cho đề 95 km/h), tr.Mẫu 75 km/h không cần; sách tr.53, II-16.

> f=f0 nếu v≤22,2; f=f0(1+v²/1500) nếu v>22,2

v m/s; mô hình ghép thực nghiệm có bước nhảy tại ngưỡng.

## 10. Những điểm cần sửa khi dùng bài mẫu làm khung

| Vấn đề trong mẫu | Cách xử lý trong bài Nhóm 2 |
| --- | --- |
| Dùng G vừa là kg vừa là N; có chỗ lẫn khối lượng xe khác | Tách m và G=mg; một nguồn dữ liệu duy nhất. |
| Công suất chọn có dự trữ nhưng bảng đặc tính dùng công suất trước dự trữ | Đặc tính, mômen, lực kéo đều dùng chung Nmax đã công bố. |
| Hiệu suất xuất hiện 0,89 và 0,98; φ xuất hiện 0,9 và 0,8 | Giữ η=0,89 và φ=0,8 trong toàn bộ phép tính. |
| Hệ số chuyển tải động lẫn với phần tải cầu sau | Gφ=0,7G; hệ số thay đổi tải động chọn 1 riêng biệt. |
| Mẫu chạy 75 km/h nên f=f0; đề mới chạy 95 km/h | Bổ sung miền tốc độ cao theo II-16 tr.53. |
| Ngoặc D ở (3.3.4) không rõ / thiếu | Cả Pk−Pw chia G. |
| Pc hoặc Pφ bị gọi là cản lăn | Pc là tổng cản đường bằng; Pφ là giới hạn bám. |
| Số lùi nói bằng số I nhưng phép tính dùng 1,2 số I | Thống nhất iR=1,2ih1=8,4. |
| Cực đại mômen chỉ lấy từ bảng mẫu thưa | Tính đạo hàm: nM=0,75nN. |
| Công thức hình thang in chia 0,5 | Dùng nhân 0,5; không khẳng định mọi ô bảng mẫu đều sai. |
| Khởi đầu tốc độ động cơ quá thấp, dễ gọi nhầm tăng tốc từ đứng yên | Chọn nmin=800 rpm và ghi rõ bỏ giai đoạn trượt ly hợp. |
| Công thức Ne cuối tr.140 sách có dấu chia không khớp (I-2) | Dùng phép nhân đa thức đúng theo sách tr.11, (I-2). |

## 11. Cách sử dụng bộ hồ sơ

Bang_tinh_Nhom_2.xlsx có các trang Dau_vao, Thiet_ke, Dong_co, Luc_keo, Bieu_do_dong, Tang_toc, Cong_thuc_nguon và Hinh_anh. Các trang công thức sẽ tính lại khi mở bằng Excel. Tang_toc và Hinh_anh là bản kết quả cố định được đánh dấu rõ; thay tham số phải chạy lại Python để tái tạo chúng. Các biểu đồ động trong Excel lấy dữ liệu từ ô công thức, còn tám hình xuất bản thể hiện bộ tham số gốc.

Để tính lại toàn bộ: chỉnh nhom2.json, cài requirements.txt, chạy python build_model.py nhom2.json ket_qua_moi. Đổi số cấp hộp số phải tái tạo workbook. Chương trình dừng nếu lịch chuyển số không phù hợp miền tốc độ hoặc mục tiêu tăng tốc không đạt được với j>0. Tệp kiem_tra.json lưu kết quả kiểm tra và sai số; CSV lưu lịch sử chuyển động chi tiết.

Nguồn: (1) Nguyễn Hữu Cẩn và cộng sự, Lý thuyết ô tô máy kéo, bản in 2005 do người dùng cung cấp. (2) BTL Lý thuyết ô tô – Tính toán sức kéo ô tô Nhóm 1, tệp PDF người dùng cung cấp. (3) Ảnh đề BTL Nhóm 2 trong cuộc trao đổi. Chưa bổ sung thông số từ nhà sản xuất.