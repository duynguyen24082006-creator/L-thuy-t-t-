#!/usr/bin/env python3
"""Generate the Group 2 traction calculation. SI internally; sources in report.
Usage: python build_model.py [config.json] [output_directory]
"""
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/traction-mpl')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/traction-cache')
import json, sys, math, csv, html, zipfile, hashlib
from pathlib import Path
import numpy as np
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq, minimize_scalar
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import xlsxwriter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from docx import Document
from docx.shared import Inches, Pt

ROOT=Path(__file__).resolve().parent
C=json.loads(Path(sys.argv[1] if len(sys.argv)>1 else ROOT/'nhom2.json').read_text())
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'ket_qua_nhom2'
OUT.mkdir(parents=True,exist_ok=True)
FIG=OUT/'hinh';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
g=C['g'];m=C['m0']+C['payload']+C['people']*C['person_mass'];G=m*g
G1=G*C['front_share'];G2=G-G1;W=C['K']*C['area'];eta=C['eta'];vm=C['vmax_kmh']/3.6
rb=(C['tire_B_in']+C['rim_d_in']/2)*.0254*C['tire_lambda']
def f(v):
    z=np.asarray(v);return np.where(z<=C['f_threshold_ms'],C['f0'],C['f0']*(1+z*z/1500))
def pw(v):return W*np.asarray(v)**2
def pc(v):return G*f(v)+pw(v)
nv=C['lambda_v']*C['nN'];poly=lambda x:C['a']*x+C['b']*x*x-C['c']*x*x*x
Nv=float(pc(vm)*vm/(1000*eta));Nreq=Nv/poly(C['lambda_v']);Nmax=Nreq*C['power_factor']
i0=2*math.pi*rb*nv/(60*C['top_ratio']*vm)
ratios=np.geomspace(C['first_ratio'],C['top_ratio'],C['gears'])
q=(ratios[0]/ratios[-1])**(1/(len(ratios)-1));Pphi=C['phi']*G2
def ne(n):return Nmax*poly(np.asarray(n)/C['nN'])
def me(n):return 60000/(2*math.pi)*ne(n)/np.asarray(n)
def speed(n,h):return 2*math.pi*np.asarray(n)*rb/(60*i0*h)
def rpm(v,h):return np.asarray(v)*60*i0*h/(2*math.pi*rb)
def pk(v,h):return me(rpm(v,h))*i0*h*eta/rb
def delta(h):return 1.05+.05*h*h
def acc(v,h):return (np.minimum(pk(v,h),Pphi)-pc(v))/(m*delta(h))
nM=C['nN']*C['b']/(2*C['c']);Mmax=float(me(nM))
lower=C['psi_max']*G*rb/(Mmax*i0*eta);upper=Pphi*rb/(Mmax*i0*eta)
vpeak=float(speed(nM,ratios[0]));Ppeak=float(pk(vpeak,ratios[0]));Dpeak=(Ppeak-pw(vpeak))/G
alpha=math.asin(float(Dpeak)/math.sqrt(1+C['f0']**2))-math.atan(C['f0'])
grade=math.tan(alpha)

def trajectory(points):
    """Integrate powered phases in v, shifts in t. Split discontinuity at f threshold."""
    v=float(speed(C['nmin'],ratios[0]));t=s=0.;rows=[['Bắt đầu',1,0.,v,0.,float(C['nmin']),float(acc(v,ratios[0]))]]
    stages=[];reference_t=reference_s=0.;end=C['target_fraction']*vm
    for k,h in enumerate(ratios):
        stop=min(float(speed(nv,h)),end)
        startv=v;startt=t;starts=s
        if stop<=v:raise ValueError('Shift schedule or target does not fit selected ratios')
        # Each smooth side is integrated independently; endpoints carry one-sided f values.
        cuts=[v]+([C['f_threshold_ms']] if v<C['f_threshold_ms']<stop else [])+[stop]
        for va,vb in zip(cuts[:-1],cuts[1:]):
            grid=np.linspace(va,vb,max(12,int(points*(vb-va)/(stop-startv))))
            evalgrid=grid.copy()
            if va==C['f_threshold_ms']:evalgrid[0]+=1e-8
            if vb==C['f_threshold_ms']:evalgrid[-1]-=1e-8
            js=acc(evalgrid,h)
            if np.min(js)<=0:raise ValueError('Target is unreachable with positive acceleration')
            reference_t+=quad(lambda x:1/float(acc(x,h)),va,vb,epsabs=1e-9)[0]
            reference_s+=quad(lambda x:x/float(acc(x,h)),va,vb,epsabs=1e-9)[0]
            for z in range(1,len(grid)):
                dv=grid[z]-grid[z-1]
                dt=.5*(1/js[z-1]+1/js[z])*dv
                ds=.5*(grid[z-1]/js[z-1]+grid[z]/js[z])*dv
                t+=dt;s+=ds;v=float(grid[z])
                rows.append(['Kéo',k+1,t,v,s,float(rpm(v,h)),float(js[z])])
        stages.append(dict(kind='Kéo',gear=k+1,v0=startv*3.6,v1=v*3.6,dt=t-startt,ds=s-starts,n_after=float(rpm(v,h))))
        if stop>=end-1e-9:break
        oldv=v;oldt=t;olds=s
        def coast(_,y):return [-float(pc(y[0]))/(m*C['delta_coast']),y[0]]
        sol=solve_ivp(coast,[0,C['shift_seconds']],[v,0.],rtol=1e-10,atol=1e-11,dense_output=True,max_step=.02)
        for tau in np.linspace(0,C['shift_seconds'],31)[1:]:
            cv,cs=sol.sol(tau);rows.append(['Chuyển số',k+1,oldt+tau,float(cv),olds+float(cs),0.,coast(tau,[cv,cs])[0]])
        v=float(sol.y[0,-1]);t+=C['shift_seconds'];s+=float(sol.y[1,-1])
        reference_t+=C['shift_seconds'];reference_s+=float(sol.y[1,-1])
        na=float(rpm(v,ratios[k+1]))
        if na<C['nmin']:raise ValueError('Post-shift rpm below stable speed')
        stages.append(dict(kind='Chuyển số',gear=f'{k+1}→{k+2}',v0=oldv*3.6,v1=v*3.6,dt=t-oldt,ds=s-olds,n_after=na))
    return rows,stages,reference_t,reference_s
rows,stages,tref,sref=trajectory(C['drive_points'])
rows_fine,_,_,_=trajectory(C['drive_points']*2)
tend=rows[-1][2];send=rows[-1][4]
vstart=rows[0][3]*3.6
checks={'mass_kg':m,'weight_N':G,'required_power_at_95_kW':Nv,'design_peak_power_kW':Nmax,'peak_torque_Nm':Mmax,'i0':i0,'first_ratio_bounds':[lower,upper], 'ratios':ratios.tolist(),'time_s':tend,'distance_m':send,'reference_quad_time_s':tref,'reference_quad_distance_m':sref,'relative_time_error':abs(tend-tref)/tref,'relative_distance_error':abs(send-sref)/sref,'time_change_double_resolution_s':rows_fine[-1][2]-tend,'distance_change_double_resolution_m':rows_fine[-1][4]-send}
ncheck=np.linspace(C['nmin'],C['nN'],151)
checks['max_power_identity_error_W']=max(float(np.max(np.abs(pk(speed(ncheck,h),h)*speed(ncheck,h)-eta*ne(ncheck)*1000))) for h in ratios)
checks['equilibrium_95_N']=float(pk(vm,ratios[-1])-pc(vm))
checks['psi_max_margin_N']=float(Ppeak-C['psi_max']*G-pw(vpeak))
checks['adhesion_margin_N']=float(Pphi-Ppeak)
assert abs(G1+G2-G)<1e-8 and lower<ratios[0]<upper
assert checks['max_power_identity_error_W']<1e-7
assert checks['relative_time_error']<1e-4 and checks['relative_distance_error']<1e-4
assert checks['psi_max_margin_N']>0 and checks['adhesion_margin_N']>0
(OUT/'kiem_tra.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
(OUT/'tham_so.json').write_text(json.dumps(C,ensure_ascii=False,indent=2))
with (OUT/'tang_toc_chi_tiet.csv').open('w',newline='',encoding='utf-8-sig') as fp:
    writer=csv.writer(fp);writer.writerow(['Giai đoạn','Số','t (s)','v (m/s)','S (m)','n (rpm)','j (m/s2)']);writer.writerows(rows)

figures=[]
def savefig(fig,name,title):
    fig.tight_layout();fig.savefig(FIG/(name+'.png'),dpi=180);fig.savefig(FIG/(name+'.pdf'));figures.append((name,title,fig))
n=np.linspace(C['nmin'],C['nN']*1.1,300)
fig,ax=plt.subplots(figsize=(8,4.6));ay=ax.twinx();ax.plot(n,ne(n),color='#0369a1',label='Nₑ');ay.plot(n,me(n),color='#b45309',label='Mₑ')
ax.scatter([nv,C['nN']],[ne(nv),ne(C['nN'])],color='#0369a1');ay.scatter([nM],[Mmax],color='#b45309')
ax.set(xlabel='Tốc độ động cơ n (vòng/phút)',ylabel='Công suất Nₑ (kW)',title='1. Đặc tính ngoài diesel thiết kế');ay.set_ylabel('Mômen Mₑ (N·m)');ax.grid(alpha=.25)
ax.text(.02,.96,f'Nmax = {Nmax:.2f} kW tại {C["nN"]} rpm\nMmax = {Mmax:.2f} N·m tại {nM:.0f} rpm',transform=ax.transAxes,va='top',fontsize=9)
savefig(fig,'01_dac_tinh_dong_co','Đặc tính ngoài động cơ')
vs=np.unique(np.r_[np.linspace(0,vm*1.12,600),C['f_threshold_ms']-1e-7,C['f_threshold_ms']+1e-7]);palette=plt.cm.viridis(np.linspace(.05,.85,len(ratios)))
for key,num,title,ylabel in [('power',2,'Cân bằng công suất','Công suất (kW)'),('force',3,'Cân bằng lực kéo','Lực (kN)'),('dynamic',4,'Nhân tố động lực học','D (không thứ nguyên)'),('acc',5,'Gia tốc theo tay số','j (m/s²)'),('inverse',6,'Gia tốc ngược','1/j (s²/m)')]:
    fig,ax=plt.subplots(figsize=(8,4.6))
    for k,h in enumerate(ratios):
        vg=np.linspace(float(speed(C['nmin'],h)),float(speed(C['nN'],h)),500)
        if vg[0]<C['f_threshold_ms']<vg[-1]:vg=np.sort(np.r_[vg,C['f_threshold_ms']-1e-7,C['f_threshold_ms']+1e-7])
        pp=pk(vg,h);jj=acc(vg,h)
        y={'power':eta*ne(rpm(vg,h)),'force':pp/1000,'dynamic':(pp-pw(vg))/G,'acc':jj,'inverse':np.divide(1,jj,out=np.full_like(jj,np.nan),where=jj>0)}[key]
        if key=='inverse':y=np.where(vg<=C['target_fraction']*vm,y,np.nan)
        ax.plot(vg*3.6,y,color=palette[k],label=f'Số {k+1}')
    if key=='power':ax.plot(vs*3.6,pc(vs)*vs/1000,'r--',label='Nf + Nw');ax.plot(vs*3.6,G*f(vs)*vs/1000,':',color='gray',label='Nf')
    if key=='force':ax.plot(vs*3.6,pc(vs)/1000,'r--',label='Pf + Pw');ax.axhline(Pphi/1000,color='gray',ls=':',label='Giới hạn bám Pφ')
    if key=='dynamic':ax.plot(vs*3.6,f(vs),'r--',label='f(v)');ax.plot(vs*3.6,(Pphi-pw(vs))/G,':',color='gray',label='Dφ (tải tĩnh)')
    if key=='acc':ax.axhline(0,color='gray',lw=.8)
    ax.axvline(C['vmax_kmh'],color='gray',ls=':',lw=.8);ax.set(xlabel='Vận tốc v (km/h)',ylabel=ylabel,title=f'{num}. {title}',xlim=(0,C['vmax_kmh']*1.13));ax.grid(alpha=.22);ax.legend(ncol=3,fontsize=8)
    savefig(fig,f'{num:02d}_{key}',title)
tt=np.array([r[2] for r in rows]);vv=np.array([r[3]*3.6 for r in rows]);ss=np.array([r[4] for r in rows])
for num,name,yy,ylabel,title in [(7,'thoi_gian',tt,'Thời gian t (s)','Thời gian tăng tốc'),(8,'quang_duong',ss,'Quãng đường S (m)','Quãng đường tăng tốc')]:
    fig,ax=plt.subplots(figsize=(8,4.6));ax.plot(vv,yy,color='#0369a1',lw=1.7)
    for stage in stages:
        if stage['kind']=='Chuyển số':ax.axvspan(stage['v1'],stage['v0'],color='#d97706',alpha=.12)
    ax.scatter([vv[-1]],[yy[-1]],color='#b45309');ax.annotate(f'{vv[-1]:.2f} km/h; {yy[-1]:.2f}',(vv[-1],yy[-1]),xytext=(-145,-15),textcoords='offset points')
    ax.set(xlabel='Vận tốc v (km/h)',ylabel=ylabel,title=f'{num}. {title} (có mất tốc độ khi chuyển số)');ax.grid(alpha=.25);savefig(fig,f'{num:02d}_{name}',title)
with PdfPages(OUT/'08_do_thi_A4.pdf') as pdf:
    for _,_,fig in figures:
        original_size=fig.get_size_inches().copy()
        fig.set_size_inches(297/25.4,210/25.4)
        pdf.savefig(fig)
        fig.set_size_inches(original_size)

# Formula catalogue: source numbering preserved, normalized notation and SI units.
formula_rows=[
('2.1.1; tải cầu','1','136–138','m=m0+nc·mn+mh; G=mg; G1=β1G; G2=β2G','Tách kg và N; tải cầu ở trạng thái tĩnh.'),
('2.2.1','2','139','Nv=[G·ψv·vmax+K·A·vmax³]/(1000η)','Nv kW; v m/s; ψv=f(vmax) trên đường bằng.'),
('2.2.2','3','140, IV-49','Nmax=Nv/(aλ+bλ²−cλ³)','Công suất thiết kế cực đại, λ=nv/nN.'),
('2.2.3','3','140 (cần phân biệt công suất sử dụng)','Nchọn=kN·Nmax','Bài mẫu chọn kN=1,1–1,25; bài này kN=1 để khép kín vmax=95.'),
('2.2.4','3','12, I-3','Me=60000·Ne/(2πn)','Ne kW, n rpm, Me N·m.'),
('2.2.5','3','140–141','nv=λ·nN','Không coi λ là hằng số cho mọi điểm trên đặc tính.'),
('2.2.6','4','11, I-2; 12','Ne=Nmax[a·x+b·x²−c·x³], x=n/nN','Diesel phun trực tiếp: a=0,5; b=1,5; c=1.'),
('2.3.1 (i0)','5','141, IV-51','i0=2π·rb·nv/(60·ih_top·ip·vmax)','ip=1, truyền lực phụ không có.'),
('2.3.1 (rb; mẫu trùng số)','5','37–38','r0=(B+d/2)·0,0254; rb=λt·r0','B,d inch; công thức hình học gần đúng cho lốp kiểu cũ.'),
('2.3.2','5','35; 95–96; 127–128','Pψ+Pw+Pj ≤ Pk ≤ Pφ','Ở vận tốc thấp thường bỏ Pw khi chọn số I.'),
('2.3.3','6','127–128','ih1 ≥ ψmax·G·rb/(Memax·i0·ip·η)','Sau chọn phải kiểm lại Pw ở điểm mômen lớn nhất.'),
('2.3.4','6','127–128, IV-32','Pφ=φ·mZ·Gφ','mZ là hệ số thay đổi tải động; chọn 1 vì thiếu vị trí trọng tâm.'),
('2.3.5','6','128, IV-33','ih1 ≤ φ·mZ·Gφ·rb/(Memax·i0·ip·η)','Gφ=G2 nếu cầu sau chủ động.'),
('2.3.6','7','129–131','q=(ih1/ih_top)^(1/(z−1))','Cấp số nhân.'),
('2.3.7','7','129–131','ihk=ih1/q^(k−1)','Số cao nhất chọn truyền thẳng.'),
('2.3.8','8','142','iR=(1,2…1,3)ih1','Bài này chọn 1,2; kiểm tra bám số lùi.'),
('3.1.1','8','88–89, IV-1…3','Ne=Nt+Nf+Nw+Ni+Nj','Quy ước dốc lên, tăng tốc, không gió.'),
('3.1.2','8','89, IV-2','Nk=η·Ne','Tổn thất truyền lực đã tính trong η.'),
('3.1.3','9','89; 95–96','Nc=Nf+Nw=(Gf+KA·v²)v/1000','Trên đường bằng; đơn vị kW.'),
('3.2.1','9','95–96, IV-9…10','Pk=Pf+Pi+Pw+Pj','Pf=fGcosα; Pi=Gsinα; Pj=mδj.'),
('3.2.2','10','16; 95–96','Pk=Me·i0·ih·ip·η/rb','Lực kéo tính từ mômen; không trừ Pf tại đây.'),
('3.2.3','11','95–96','Pc=Pf+Pw=fG+KA·v²','Pc là tổng cản đường bằng, không riêng cản lăn.'),
('3.3.1','12','101–102, IV-15…16','D=(Pk−Pw)/G=ψ+δj/g','D không có đơn vị.'),
('3.3.2','12','35; 101–102 (suy ra)','Dφ=(Pφ−Pw)/G','Cản không khí cũng phải trừ trong giới hạn Dφ.'),
('3.3.3','12','35; 101–102 (suy ra)','Dφ≥D≥ψ','Vùng đủ kéo, còn bám; D≥ψ tương ứng j≥0.'),
('3.3.4','12','101–102','Dk=[Me·i0·ihk·η/rb−KA·v²]/G','Sửa ngoặc ở mẫu: toàn bộ hiệu chia G.'),
('3.3.5','12','129–131','v=2π·n·rb/(60·i0·ih·ip)','v m/s; nhân 3,6 để đổi km/h.'),
('3.4.1','14','102; 107–109','D=fcosα+sinα+δj/g ≈ f+i+δj/g','i=tanα; dạng xấp xỉ chỉ cho dốc nhỏ.'),
('3.4.2','14','109, IV-23','j=g(D−ψ)/δ','Đường bằng ψ=f(v).'),
('3.4.3','14','33–34, I-49…53','δ=1,05+0,05ih²','Công thức kinh nghiệm; có quán tính chi tiết thì dùng I-49.'),
('3.5.1; 3.5.2','18','113–115, IV-24','dt=dv/j; t=∫dv/j','Bắt đầu ở vmin, không tự gán bắt đầu từ 0 km/h.'),
('3.5.3; 3.5.4','18','117','dS=vdt; S=∫vdt=∫v·dv/j','Có thể tích phân trực tiếp v/j theo v.'),
('3.5.5','19','116, IV-25','Δv≈ψ·g·t_shift/δcoast','Bài này tích phân thêm Pw trong khi ngắt mômen.'),
('Hình thang (không số)','18–19','Số hóa tích phân IV-24','Δt≈0,5(1/jA+1/jB)Δv; ΔS≈0,5(vA/jA+vB/jB)Δv','Bản in mẫu có chỗ ghi chia 0,5; phải nhân 0,5.'),
('Bổ sung cho đề 95 km/h','Mẫu 75 km/h không cần','53, II-16','f=f0 nếu v≤22,2; f=f0(1+v²/1500) nếu v>22,2','v m/s; mô hình ghép thực nghiệm có bước nhảy tại ngưỡng.'),
]

# Excel: live formulas in inputs, design, engine and gear curves. Integration is labelled snapshot.
wb=xlsxwriter.Workbook(str(OUT/'Bang_tinh_Nhom_2.xlsx'));wb.set_calc_mode('auto')
fmt_head=wb.add_format({'bold':True,'bg_color':'#164E63','font_color':'white','text_wrap':True,'border':1})
fmt_num=wb.add_format({'num_format':'0.0000'});fmt_input=wb.add_format({'bg_color':'#FEF3C7','num_format':'0.0000'});fmt_wrap=wb.add_format({'text_wrap':True,'valign':'top'})
guide=wb.add_worksheet('Huong_dan');guide.set_column('A:A',110)
guide_text=[
'BÀI TẬP LỚN LÝ THUYẾT Ô TÔ – NHÓM 2',
'Ô vàng trong Dau_vao là dữ liệu có thể sửa. Thiet_ke, Dong_co và Luc_keo dùng công thức Excel và có giá trị lưu sẵn.',
'Tang_toc và Hinh_anh là kết quả tích phân/đồ thị của bộ tham số gốc, KHÔNG tự tính lại khi sửa ô Excel.',
'Để tái tạo toàn bộ kết quả, sửa nhom2.json và chạy: python build_model.py nhom2.json ket_qua_moi',
'Cài các thư viện theo requirements.txt. CSV chi tiết và kiem_tra.json phục vụ kiểm tra độc lập.',
'Đề cho KG được hiểu là kg khối lượng; trọng lực tính với g=9,81 m/s². 70 kg/người là giả thiết.',
'Công suất cực đại thiết kế là giá trị lý thuyết tối thiểu. Chưa chọn một động cơ thương mại cụ thể.',
'Phép tăng tốc: đường bằng, đủ tải, không gió, 4 lần chuyển số 1 s; không mô phỏng trượt ly hợp từ đứng yên.',
'Hệ số cản lăn ghép theo ngưỡng 22,2 m/s có bước nhảy thực nghiệm; không phải lực thực tế đột ngột thay đổi.',
'Trang nguồn là số in trong tài liệu. PDF sách = trang in +1; PDF bài mẫu = trang in +7.',
'Các giá trị và công thức đã kiểm tra bằng Python; chưa chạy ứng dụng Microsoft Excel/LibreOffice.'
]
for r,line in enumerate(guide_text):guide.write(r,0,line,fmt_head if r==0 else fmt_wrap);guide.set_row(r,42 if r else 30)
ins=wb.add_worksheet('Dau_vao');ins.write_row(0,0,['Tham số','Giá trị','Đơn vị','Nguồn / giải thích'],fmt_head);ins.set_column('A:A',23);ins.set_column('B:B',17);ins.set_column('C:C',16);ins.set_column('D:D',82)
given={'m0','payload','people','front_share','vmax_kmh','psi_max'}
units={'m0':'kg','payload':'kg','people':'người','person_mass':'kg/người','g':'m/s²','vmax_kmh':'km/h','K':'N·s²/m⁴','area':'m²','f_threshold_ms':'m/s','tire_B_in':'inch','rim_d_in':'inch','nN':'rpm','nmin':'rpm','shift_seconds':'s'}
notes={'eta':'Tự chọn hiệu suất tổng, giữ nhất quán cho mọi công thức.','K':'K đã gộp hệ số khí động theo dạng Pw=KAv²; không nhân thêm ρ/2.','area':'Diện tích cản chính diện giả định; chưa có kích thước xe.','power_factor':'1,0: công suất thiết kế khép kín vmax; tăng hệ số này sẽ làm thay đổi vận tốc cân bằng.','lambda_v':'Chọn 0,9 cho diesel; nv=2340 rpm.','tire_B_in':'Dự chọn lốp 8.25R16, phải kiểm tra catalogue trước khi chọn sản phẩm.','tire_lambda':'Hệ số bán kính lăn dự chọn 0,935.','first_ratio':'Chọn 7 sau kiểm tra điều kiện cản đường và bám.','drive_points':'Số điểm cho mỗi pha kéo, tích phân tách ở ngưỡng f.'}
refs={}
for r,(key,val) in enumerate(C.items(),1):
    refs[key]=f"Dau_vao!$B${r+1}";ins.write(r,0,key);ins.write_number(r,1,val,fmt_input);ins.write(r,2,units.get(key,'–'));ins.write(r,3,'ĐỀ BÀI' if key in given else notes.get(key,'TỰ CHỌN / quy ước mô hình'),fmt_wrap)
R=lambda k:refs[k]
des=wb.add_worksheet('Thiet_ke');des.set_column('A:A',30);des.set_column('B:B',22);des.set_column('C:C',65);des.write_row(0,0,['Đại lượng','Giá trị','Đơn vị / ý nghĩa'],fmt_head)
dr={};dvalues={}
def design(key,formula,value,note):
    rr=len(dr)+1;dr[key]=f'Thiet_ke!$B${rr+1}';dvalues[key]=value;des.write(rr,0,key);des.write_formula(rr,1,formula,fmt_num,float(value));des.write(rr,2,note)
design('m',f'={R("m0")}+{R("payload")}+{R("people")}*{R("person_mass")}',m,'kg')
design('G',f'={dr["m"]}*{R("g")}',G,'N')
design('G1',f'={dr["G"]}*{R("front_share")}',G1,'N; tải tĩnh cầu trước')
design('G2',f'={dr["G"]}-{dr["G1"]}',G2,'N; tải tĩnh cầu sau')
design('vmax',f'={R("vmax_kmh")}/3.6',vm,'m/s')
design('rb',f'=({R("tire_B_in")}+{R("rim_d_in")}/2)*0.0254*{R("tire_lambda")}',rb,'m')
design('W',f'={R("K")}*{R("area")}',W,'N·s²/m²')
design('f_vmax',f'=IF({dr["vmax"]}<={R("f_threshold_ms")},{R("f0")},{R("f0")}*(1+{dr["vmax"]}^2/1500))',f(vm),'–')
design('nv',f'={R("lambda_v")}*{R("nN")}',nv,'rpm; điểm thiết kế tốc độ cực đại và chuyển số')
design('Nv',f'=({dr["G"]}*{dr["f_vmax"]}*{dr["vmax"]}+{dr["W"]}*{dr["vmax"]}^3)/(1000*{R("eta")})',Nv,'kW; công suất cần ở động cơ tại vmax')
design('Nmax',f'={dr["Nv"]}/({R("a")}*{R("lambda_v")}+{R("b")}*{R("lambda_v")}^2-{R("c")}*{R("lambda_v")}^3)*{R("power_factor")}',Nmax,'kW; đỉnh đặc tính thiết kế')
design('nM',f'={R("nN")}*{R("b")}/(2*{R("c")})',nM,'rpm; đỉnh mômen của đa thức')
design('Mmax',f'=60000/(2*PI())*{dr["Nmax"]}/{R("nN")}*({R("a")}+{R("b")}*{dr["nM"]}/{R("nN")}-{R("c")}*({dr["nM"]}/{R("nN")})^2)',Mmax,'N·m')
design('i0',f'=2*PI()*{dr["rb"]}*{dr["nv"]}/(60*{R("top_ratio")}*{dr["vmax"]})',i0,'–')
design('Pphi',f'={R("phi")}*{dr["G2"]}',Pphi,'N; bám theo tải tĩnh cầu sau')
design('ih1_min',f'={R("psi_max")}*{dr["G"]}*{dr["rb"]}/({dr["Mmax"]}*{dr["i0"]}*{R("eta")})',lower,'–; chưa kể Pw, kiểm tra lại sau khi chọn')
design('ih1_max',f'={dr["Pphi"]}*{dr["rb"]}/({dr["Mmax"]}*{dr["i0"]}*{R("eta")})',upper,'–; giới hạn bám')
design('q',f'=({R("first_ratio")}/{R("top_ratio")})^(1/({R("gears")}-1))',q,'–; workbook cố định 5 trang số, đổi số cấp cần chạy Python')
for k,h in enumerate(ratios):design(f'ih{k+1}',f'={R("first_ratio")}/{dr["q"]}^{k}',h,'–')
design('iR',f'={R("reverse_factor")}*{R("first_ratio")}',C['reverse_factor']*ratios[0],'–; số lùi')
eng=wb.add_worksheet('Dong_co');eng.set_column('A:F',20);eng.write_row(0,0,['n (rpm)','x=n/nN','Ne (kW)','Me (N·m)','Nk (kW)'],fmt_head)
for r in range(1,102):
    ex=r+1;nn=C['nmin']+(C['nN']*1.1-C['nmin'])*(r-1)/100
    eng.write_formula(r,0,f'={R("nmin")}+({R("nN")}*1.1-{R("nmin")})*{r-1}/100',fmt_num,nn)
    eng.write_formula(r,1,f'=A{ex}/{R("nN")}',fmt_num,nn/C['nN'])
    eng.write_formula(r,2,f'={dr["Nmax"]}*({R("a")}*B{ex}+{R("b")}*B{ex}^2-{R("c")}*B{ex}^3)',fmt_num,float(ne(nn)))
    eng.write_formula(r,3,f'=60000*C{ex}/(2*PI()*A{ex})',fmt_num,float(me(nn)))
    eng.write_formula(r,4,f'=C{ex}*{R("eta")}',fmt_num,float(ne(nn)*eta))
chart=wb.add_chart({'type':'scatter','subtype':'straight'});chart.add_series({'name':'Ne (kW)','categories':['Dong_co',1,0,101,0],'values':['Dong_co',1,2,101,2]});chart.set_title({'name':'Đặc tính công suất — công thức động'});eng.insert_chart('G2',chart)
curve=wb.add_worksheet('Luc_keo');curve.freeze_panes(1,2);curve.set_column('A:O',14);curve.write_row(0,0,['Số','ih','n rpm','v m/s','v km/h','Ne kW','Me Nm','Pk N','f','Pw N','Pc N','D','delta','j m/s2','1/j s2/m'],fmt_head)
rr=1;ranges=[]
for k,h in enumerate(ratios):
    begin=rr
    for z in range(201):
        ex=rr+1;nn=C['nmin']+(C['nN']-C['nmin'])*z/200;v=float(speed(nn,h));p=float(pk(v,h));j=float(acc(v,h));ee=float(ne(nn));mm=float(me(nn))
        curve.write(rr,0,k+1)
        vals=[(f'={dr[f"ih{k+1}"]}',h),(f'={R("nmin")}+({R("nN")}-{R("nmin")})*{z}/200',nn),(f'=2*PI()*C{ex}*{dr["rb"]}/(60*{dr["i0"]}*B{ex})',v),(f'=D{ex}*3.6',v*3.6),(f'={dr["Nmax"]}*({R("a")}*(C{ex}/{R("nN")})+{R("b")}*(C{ex}/{R("nN")})^2-{R("c")}*(C{ex}/{R("nN")})^3)',ee),(f'=60000*F{ex}/(2*PI()*C{ex})',mm),(f'=G{ex}*{dr["i0"]}*B{ex}*{R("eta")}/{dr["rb"]}',p),(f'=IF(D{ex}<={R("f_threshold_ms")},{R("f0")},{R("f0")}*(1+D{ex}^2/1500))',float(f(v))),(f'={dr["W"]}*D{ex}^2',float(pw(v))),(f'={dr["G"]}*I{ex}+J{ex}',float(pc(v))),(f'=(H{ex}-J{ex})/{dr["G"]}',float((p-pw(v))/G)),(f'=1.05+0.05*B{ex}^2',delta(h)),(f'=(MIN(H{ex},{dr["Pphi"]})-K{ex})/({dr["m"]}*M{ex})',j),(f'=IF(N{ex}>0,1/N{ex},"")',1/j if j>0 else '')]
        for col,(formula,value) in enumerate(vals,1):curve.write_formula(rr,col,formula,fmt_num,value)
        rr+=1
    ranges.append((begin,rr-1))
charts=wb.add_worksheet('Bieu_do_dong')
for idx,(col,title) in enumerate([(5,'Công suất động cơ theo vận tốc'),(7,'Lực kéo Pk'),(11,'Nhân tố D'),(13,'Gia tốc j')]):
    ch=wb.add_chart({'type':'scatter','subtype':'straight'})
    for k,(start,end) in enumerate(ranges):ch.add_series({'name':f'Số {k+1}','categories':['Luc_keo',start,4,end,4],'values':['Luc_keo',start,col,end,col]})
    ch.set_title({'name':title});ch.set_x_axis({'name':'v (km/h)'});charts.insert_chart(idx*17,0,ch)
ts=wb.add_worksheet('Tang_toc');ts.set_column('A:A',20);ts.set_column('B:G',17);ts.write(0,0,'BẢN KẾT QUẢ CỐ ĐỊNH — sửa JSON và chạy Python để tính lại',fmt_head);ts.write_row(2,0,['Giai đoạn','Số','t (s)','v (m/s)','S (m)','n (rpm)','j (m/s²)'],fmt_head)
for r,row in enumerate(rows,3):ts.write_row(r,0,row)
src=wb.add_worksheet('Cong_thuc_nguon');src.set_column('A:A',31);src.set_column('B:C',23);src.set_column('D:D',66);src.set_column('E:E',85);src.write_row(0,0,['Số CT bài mẫu','Trang in mẫu','Trang in sách','Công thức chuẩn hóa','Ghi chú'],fmt_head)
for r,row in enumerate(formula_rows,1):src.write_row(r,0,row,fmt_wrap);src.set_row(r,44)
pics=wb.add_worksheet('Hinh_anh');pics.write(0,0,'ĐỒ THỊ CỐ ĐỊNH CỦA BỘ THAM SỐ GỐC',fmt_head)
for k,(name,_,_) in enumerate(figures):pics.insert_image(k*28+2,0,str(FIG/(name+'.png')),{'x_scale':.5,'y_scale':.5})
wb.close()

# Shared report structure -> Markdown, PDF, DOCX.
blocks=[]
def heading(s):blocks.append(('h',s))
def para(s):blocks.append(('p',s))
def eq(s):blocks.append(('e',s))
def table(head,data):blocks.append(('t',(head,data)))
def picture(name,caption):blocks.append(('img',(name,caption)))
def number(v,n=3):return f'{v:,.{n}f}'.replace(',','_').replace('.',',').replace('_','.')
heading('BÀI TẬP LỚN LÝ THUYẾT Ô TÔ — NHÓM 2')
para('TRƯỜNG ĐẠI HỌC BÁCH KHOA — KHOA CƠ KHÍ GIAO THÔNG. Tính toán thiết kế sức kéo ô tô tải dùng động cơ diesel, truyền lực cơ khí. Họ tên, MSV và giáo viên hướng dẫn: điền theo danh sách lớp.')
para('Bài tính thực hiện theo đề Nhóm 2 trong ảnh người dùng cung cấp. Giáo trình Nguyễn Hữu Cẩn và cộng sự, Lý thuyết ô tô máy kéo, bản in 2005 là tài liệu cơ sở; bài mẫu Nhóm 1 chỉ dùng để đối chiếu trình tự và số công thức. Các số liệu xe của bài mẫu không được coi là dữ liệu đề Nhóm 2.')
heading('1. Dữ liệu đề bài và giả thiết thiết kế')
table(['Đại lượng','Giá trị','Phân loại'],[['Loại xe / truyền lực','Tải / cơ khí','Đề bài'],['Khối lượng bản thân','3.450 kg','Đề bài'],['Tải hàng định mức','4.100 kg','Đề bài'],['Số người, kể cả lái','2','Đề bài'],['Phân bố cầu trước / sau','0,30 / 0,70','Đề bài'],['Vận tốc cực đại yêu cầu','95 km/h','Đề bài'],['Sức cản đường lớn nhất ψmax','0,31','Đề bài'],['Động cơ','Diesel','Đề bài']])
para('Chữ [KG] của đề được hiểu là đơn vị khối lượng kg. Ký hiệu G trong công thức động lực học dưới đây luôn là trọng lực N, không thay trực tiếp số kg vào công thức lực. Giả thiết G0 chưa gồm 2 người; tải 4.100 kg là tải hàng. Nếu quy ước đề của giảng viên khác, cần sửa khối lượng tương ứng.')
table(['Thông số tự chọn','Giá trị','Cơ sở / giới hạn'],[['Khối lượng mỗi người; g','70 kg; 9,81 m/s²','Quy ước tính'],['Bố trí truyền động','4×2, cầu sau chủ động; bánh sau kép','Đề chưa cho bố trí cầu'],['Hiệu suất tổng η','0,89','Giả định thiết kế, tương thích bài mẫu'],['K; diện tích A','0,65 N·s²/m⁴; 4,5 m²','Giả định cản khí động; W=KA=2,925'],['f0; φ','0,015; 0,80','Đường tốt, khô; hệ số bám tính theo tải tĩnh'],['Lốp dự chọn; λt','8.25R16; 0,935','Chỉ là chọn kích thước sơ bộ'],['Đặc tính diesel','a=0,5; b=1,5; c=1','Giả thiết diesel 4 kỳ phun trực tiếp, sách tr.12'],['nN; λv; nmin','2.600 rpm; 0,90; 800 rpm','n_v=2.340 rpm, trong khoảng gợi ý sách tr.142'],['Hộp số','5 số tiến; số cao nhất =1; ip=1','Sơ đồ thiết kế lựa chọn'],['Chuyển số','n=2.340 rpm; 1 giây/lần','Lịch cố định; chưa tối ưu thời gian'],['Quán tính','δh=1,05+0,05ih²; δcoast=1,05','Kinh nghiệm sách; lúc chuyển số ngắt quán tính động cơ']])
para('Không có kích thước bao xe, vị trí trọng tâm, thông số động cơ thực và bảng tải lốp nên đây là một phương án thiết kế tính toán có điều kiện. Không đồng nhất động cơ tương đương này với một mã động cơ thương mại.')
heading('2. Trọng lượng toàn bộ và tải trọng các cầu')
eq('m = m0 + mh + nc·mn = 3450 + 4100 + 2×70 = 7690 kg')
eq(f'G = m·g = {number(G,1)} N; G1 = 0,30G = {number(G1,2)} N; G2 = 0,70G = {number(G2,2)} N')
table(['Vị trí','Khối lượng tương đương','Trọng lực'],[['Toàn xe',f'{number(m,0)} kg',f'{number(G,1)} N'],['Cầu trước',f'{number(m*.3,0)} kg',f'{number(G1,2)} N'],['Cầu sau',f'{number(m*.7,0)} kg',f'{number(G2,2)} N']])
para('Với hai bánh trước và bốn lốp sau, tải tĩnh bình quân mỗi lốp trước là 1.153,5 kg, mỗi lốp sau là 1.345,75 kg. Khi chọn sản phẩm phải kiểm tra tải cho lắp đơn/lắp kép, cấp tốc độ ít nhất 95 km/h, áp suất và dự trữ tải động. Chưa có catalogue nên không kết luận lốp dự chọn đã được chứng nhận đủ tải.')
para('Nếu giảng viên quy ước g=10 m/s² như bài mẫu thì G=76.900 N, G1=23.070 N, G2=53.830 N. Không trộn các giá trị này vào bài đang dùng g=9,81; thay g trong tệp tham số và tính lại toàn bộ.')
heading('3. Bán kính bánh xe, cản lăn và cản không khí')
eq(f'r0 = (B+d/2)·0,0254 = (8,25+16/2)·0,0254 = 0,41275 m; rb = λt·r0 = {number(rb,6)} m')
para('Công thức hình học dùng bề rộng danh nghĩa như chiều cao tiết diện, chỉ phù hợp cho chọn sơ bộ dạng lốp số inch cũ. Bán kính lăn phải được thay bằng thông số tải thực khi có catalogue; không đồng nhất bán kính tự do, tĩnh và lăn.')
eq('f(v) = 0,015 nếu v≤22,2 m/s; f(v) = 0,015(1+v²/1500) nếu v>22,2 m/s')
eq('Pf = f(v)G trên đường bằng; Pw = KAv² = 2,925v²; Pc = Pf+Pw')
para('Giáo trình tr.53, (II-16), cho hệ số cản lăn tăng theo tốc độ ở vùng trên khoảng 80 km/h. Với đề 95 km/h, không giữ f=0,015 trong phép chọn công suất. Cách ghép hai miền theo sách có bước nhảy tại 22,2 m/s (79,92 km/h): f tăng từ 0,015 lên khoảng 0,0199284. Đây là hạn chế của xấp xỉ thực nghiệm, không phải một lực vật lý nhảy đột ngột. Bảng tích phân tách tại ngưỡng; đồ thị giữ bước nhảy để minh bạch giả thiết. Có dữ liệu lốp thực thì thay bằng hàm f(v) liên tục đã hiệu chỉnh.')
eq(f'vmax = 95/3,6 = {number(vm,6)} m/s; f(vmax) = {number(float(f(vm)),7)}')
table(['Tại 95 km/h','Giá trị'],[['Pf',f'{number(float(G*f(vm)),2)} N'],['Pw',f'{number(float(pw(vm)),2)} N'],['Pc',f'{number(float(pc(vm)),2)} N'],['Công suất bánh xe Pc·v/1000',f'{number(float(pc(vm)*vm/1000),3)} kW']])
heading('4. Công suất cần thiết và đặc tính ngoài động cơ')
eq('Nv = [G·f(vmax)·vmax + K·A·vmax³]/(1000η)')
eq(f'Nv = {number(Nv,6)} kW; λv = nv/nN = 0,9; nv = 2340 rpm')
eq('Nmax = Nv/[aλv+bλv²−cλv³] = Nv/0,936')
eq(f'Nmax = {number(Nmax,6)} kW; Ne(n) = Nmax[0,5x+1,5x²−x³], x=n/2600')
eq('Me(n) = 60000Ne/(2πn) = 9549,2966Ne/n (N·m)')
para('Bài này dùng công suất thiết kế tối thiểu để đường cân bằng công suất ở số V khép kín tại đúng 95 km/h. Không nhân dự trữ rồi tiếp tục sử dụng đặc tính công suất cũ. Nếu cần chọn động cơ thương mại có dự trữ 10%, mức tham khảo là '+number(1.1*Nreq,2)+' kW (có thể xét cấp 130 kW), nhưng phải thay đặc tính thực và tính lại vận tốc cân bằng, tỷ số truyền và tăng tốc. Mức 130 kW không được dùng trong kết quả bên dưới. Phụ tải phụ kiện chưa được tách riêng ngoài η; khi dùng công suất catalogue cần xác định đó là công suất có ích nào.')
eq(f'nM = b·nN/(2c) = {number(nM,0)} rpm; Memax = {number(Mmax,3)} N·m')
table(['n (rpm)','Ne (kW)','Me (N·m)'],[[str(nn),number(float(ne(nn)),3),number(float(me(nn)),3)] for nn in [800,1000,1200,1400,1600,1800,1950,2000,2200,2340,2600]])
para('Đỉnh mômen lấy bằng đạo hàm, không chọn cực đại từ vài điểm lấy mẫu. Đặc tính ở vùng sau nN chỉ minh họa đa thức thực nghiệm; không thay thế đặc tính điều tốc của động cơ thật. Công suất tại 2.340 rpm là Nv, còn công suất cực đại của đa thức xuất hiện tại 2.600 rpm.')
picture('01_dac_tinh_dong_co','Hình 1. Đặc tính ngoài động cơ tương đương thiết kế.')
heading('5. Tỷ số truyền lực chính và hộp số')
eq(f'i0 = 2π·rb·nv/(60·ih5·vmax) = {number(i0,6)}; ih5=1')
eq('ih1_min = ψmax·G·rb/(Memax·i0·η); ih1_max = φ·G2·rb/(Memax·i0·η)')
eq(f'{number(lower,4)} ≤ ih1 ≤ {number(upper,4)}; chọn ih1=7')
para('Giới hạn dưới yêu cầu đủ lực khắc phục sức cản đường ở tốc độ thấp; giới hạn trên kiểm tra bám theo tải tĩnh cầu sau, φ=0,8. Hệ số 0,7 là tỷ lệ tải cầu chủ động, không phải hệ số chuyển tải động. Đề thiếu chiều dài cơ sở và tọa độ trọng tâm nên chưa tính chính xác phản lực cầu khi lên dốc/tăng tốc.')
eq(f'q = (ih1/ih5)^(1/4) = {number(q,6)}; ihk=ih1/q^(k−1); iR=1,2ih1=8,4')
gear_table=[]
for k,h in enumerate(ratios):gear_table.append([str(k+1),number(h,6),number(delta(h),4),number(float(speed(C['nmin'],h)*3.6),3),number(float(speed(nv,h)*3.6),3)])
table(['Số','ih','δ','v tại 800 rpm (km/h)','v tại 2340 rpm (km/h)'],gear_table)
eq(f'Pk1,max = {number(Ppeak,2)} N; Pφ = φG2 = {number(Pphi,2)} N')
eq(f'v tại Memax, số I = {number(vpeak*3.6,3)} km/h; Pψmax+Pw = {number(float(.31*G+pw(vpeak)),2)} N')
para(f'Số I đủ lực: dự trữ tại điểm mômen cực đại là {number(checks["psi_max_margin_N"],2)} N; còn dự trữ bám {number(checks["adhesion_margin_N"],2)} N. Số lùi có lực kéo cực đại xấp xỉ {number(Ppeak*1.2,2)} N, vẫn nhỏ hơn giới hạn bám tĩnh. Kết quả này không phải kiểm tra bền răng, trục hay nhiệt ly hợp; các kiểm tra đó ngoài dữ liệu đề.')
para(f'Tại điểm mômen cực đại số I, D={number(float(Dpeak),5)}. Trên dốc và tốc độ thấp, giải D=f0·cosα+sinα cho khả năng vượt dốc xấp xỉ {number(grade*100,2)}% theo giả thiết tải bám đủ. Đây là giá trị tại điểm kiểm tra, chưa tối ưu D theo tốc độ và chưa xét dịch chuyển phản lực do trọng tâm. ψmax=0,31 không có nghĩa là dốc đúng 31%; ψ đã gồm cản lăn.')
heading('6. Cân bằng lực, công suất, nhân tố động lực học và gia tốc')
eq('Pk = Me·i0·ih·η/rb; v = 2π·n·rb/(60·i0·ih)')
eq('Pk = Pf+Pi+Pw+Pj; Pf=fGcosα; Pi=Gsinα; Pw=KAv²; Pj=mδj')
eq('Nk = ηNe = Pk·v/1000; Nc=(Pf+Pw)·v/1000 trên đường bằng')
eq('D=(Pk−Pw)/G; Dφ=(Pφ−Pw)/G; δh=1,05+0,05ih²')
eq('j = g[D−f(v)]/δh = [min(Pk,Pφ)−Pf−Pw]/(mδh), khi giới hạn bám được áp dụng')
para('Trong bộ số liệu này, Pk ở cả năm số tiến nhỏ hơn Pφ nên không phải cắt lực kéo theo bám. Khi sửa tham số đến mức Pk>Pφ, mô hình gia tốc chỉ giới hạn lực truyền hữu ích bằng Pφ, tương ứng điều chỉnh mômen để tránh trượt; không mô phỏng quay trơn. Đồ thị Pk và D vẫn thể hiện yêu cầu lý thuyết từ động cơ và có đường giới hạn bám để đối chiếu.')
para('Pk ở đây là lực kéo quy đổi từ mômen truyền đến bánh xe. Pf được tính một lần trong tổng cản toàn xe. Không lấy lực kéo ròng đã trừ cản lăn ở bánh chủ động rồi tiếp tục trừ toàn bộ Pf, vì sẽ đếm cản lăn hai lần. Phân tích tiếp xúc bánh mềm–đường mềm bằng hợp lực R và lực tiếp tuyến T thuộc mô hình tiếp xúc cục bộ; bài sức kéo toàn xe này dùng lực quy đổi với các tổn thất được hạch toán nhất quán.')
for name,title,_ in figures[1:5]:picture(name,'Hình '+name[:2]+'. '+title+'. Các đường số thể hiện miền 800–2600 rpm; phần j<0 không dùng để tích phân tăng tốc.')
para(f'Tại 95 km/h, số V: Nk={number(float(eta*ne(nv)),4)} kW bằng Nf+Nw; Pk−Pc={number(checks["equilibrium_95_N"],8)} N (sai số số học). Vì vậy j tiến về 0 tại vận tốc này. Phần đặc tính vượt 95 km/h có gia tốc âm và không phải vận tốc tự tăng tốc đạt được trên đường bằng.')
heading('7. Gia tốc ngược, thời gian và quãng đường tăng tốc')
eq('t = ∫(1/j)dv; S = ∫(v/j)dv; dùng v m/s trong tích phân')
eq('Δt ≈ 0,5(1/jA+1/jB)(vB−vA); ΔS ≈ 0,5(vA/jA+vB/jB)(vB−vA)')
para(f'Bắt đầu ở nmin=800 rpm, số I: vmin={number(vstart,4)} km/h, đặt t=S=0 tại đó. Chưa tính giai đoạn xuất phát từ đứng yên với ly hợp trượt. Kết thúc ở 0,95vmax=90,25 km/h vì tích phân lý tưởng đến đúng điểm j=0 tại 95 km/h có thời gian phân kỳ. Kết quả không được ghi thành thời gian 0–95 km/h.')
para('Chuyển số khi n=2.340 rpm, thời gian gián đoạn kéo 1 s mỗi lần, tổng 4 lần. Trong khoảng chuyển số, t và S vẫn tăng nhưng v giảm; vì vậy đường t(v), S(v) có đoạn quay nhẹ sang trái. Không nối trực tiếp hai số ở cùng một vận tốc rồi bỏ mất thời gian và quãng đường chuyển số. Lịch chuyển số này là phương án quy định, chưa chứng minh là nhanh nhất.')
eq('Trong chuyển số: dv/dt = −[Gf(v)+KAv²]/(mδcoast); dS/dt=v; δcoast=1,05')
table(['Pha','v đầu (km/h)','v cuối (km/h)','Δt (s)','ΔS (m)','n cuối/sau nối (rpm)'],[[f'{r["kind"]} {r["gear"]}',number(r['v0'],3),number(r['v1'],3),number(r['dt'],3),number(r['ds'],3),number(r['n_after'],1)] for r in stages])
eq(f't({number(vstart,3)} → 90,25 km/h) = {number(tend,3)} s; S = {number(send,3)} m')
picture('06_inverse','Hình 6. Gia tốc ngược của từng số, chỉ thể hiện phần j>0 và v≤90,25 km/h.')
picture('07_thoi_gian','Hình 7. Thời gian tích lũy theo vận tốc; vùng màu nhạt là khoảng mất tốc độ khi chuyển số.')
picture('08_quang_duong','Hình 8. Quãng đường tích lũy theo vận tốc, có tính quãng đường chuyển số.')
heading('8. Kiểm tra kết quả và giới hạn áp dụng')
table(['Phép kiểm','Kết quả'],[['Khối lượng; tổng tải cầu','m=7690 kg; G1+G2=G'],['Công suất và lực kéo',f'max|Pk·v−1000ηNe|={checks["max_power_identity_error_W"]:.2e} W'],['Điều kiện số I',f'{number(lower,4)} < 7 < {number(upper,4)}; đã cộng Pw khi kiểm tra lại'],['Tích phân độc lập (quadrature)',f't={number(tref,6)} s; S={number(sref,6)} m'],['Sai lệch hình thang so với quadrature',f't: {checks["relative_time_error"]*100:.6f}%; S: {checks["relative_distance_error"]*100:.6f}%'],['Tăng đôi mật độ điểm',f'Δt={checks["time_change_double_resolution_s"]:.6f} s; ΔS={checks["distance_change_double_resolution_m"]:.6f} m']])
para('Mô hình giả định đủ tải, đường bằng tốt cho đồ thị tăng tốc, không gió, không trượt dọc, bán kính lăn và hiệu suất không đổi. Cản dốc lớn nhất chỉ dùng chọn/kiểm tra số I; không dùng ψ=0,31 cho toàn bộ đồ thị tăng tốc đường bằng. Quán tính quay được xấp xỉ theo tỷ số truyền, chưa có mômen quán tính thực của động cơ, bánh đà và bánh xe.')
para('Vận tốc 95 km/h, công suất và gia tốc là kết quả theo tham số đã chọn, không phải dữ liệu thử nghiệm của một xe thương mại. Thay diện tích cản, lốp, khối lượng mỗi người, hiệu suất hoặc đặc tính động cơ sẽ thay đổi kết quả. Chưa kiểm tra tải động cầu, bền hệ truyền lực, ổn định chống lật, phanh, nhiệt động cơ hoặc tiêu hao nhiên liệu; đề bài không cung cấp đủ dữ liệu cho các phần đó.')
heading('9. Đối chiếu công thức bài mẫu với giáo trình')
para('Số trang dưới đây là số in trên trang: sách Nguyễn Hữu Cẩn có trang PDF = trang in +1; bài mẫu có trang PDF = trang in +7. Đây là các công thức được trích theo số hiệu của bài mẫu rồi chuẩn hóa ký hiệu và đơn vị, không phải sao chép nguyên mọi lỗi trình bày của bản mẫu.')
for row in formula_rows:
    para(f'Mẫu ({row[0]}), tr.{row[1]}; sách tr.{row[2]}.')
    eq(row[3]);para(row[4])
heading('10. Những điểm cần sửa khi dùng bài mẫu làm khung')
table(['Vấn đề trong mẫu','Cách xử lý trong bài Nhóm 2'],[['Dùng G vừa là kg vừa là N; có chỗ lẫn khối lượng xe khác','Tách m và G=mg; một nguồn dữ liệu duy nhất.'],['Công suất chọn có dự trữ nhưng bảng đặc tính dùng công suất trước dự trữ','Đặc tính, mômen, lực kéo đều dùng chung Nmax đã công bố.'],['Hiệu suất xuất hiện 0,89 và 0,98; φ xuất hiện 0,9 và 0,8','Giữ η=0,89 và φ=0,8 trong toàn bộ phép tính.'],['Hệ số chuyển tải động lẫn với phần tải cầu sau','Gφ=0,7G; hệ số thay đổi tải động chọn 1 riêng biệt.'],['Mẫu chạy 75 km/h nên f=f0; đề mới chạy 95 km/h','Bổ sung miền tốc độ cao theo II-16 tr.53.'],['Ngoặc D ở (3.3.4) không rõ / thiếu','Cả Pk−Pw chia G.'],['Pc hoặc Pφ bị gọi là cản lăn','Pc là tổng cản đường bằng; Pφ là giới hạn bám.'],['Số lùi nói bằng số I nhưng phép tính dùng 1,2 số I','Thống nhất iR=1,2ih1=8,4.'],['Cực đại mômen chỉ lấy từ bảng mẫu thưa','Tính đạo hàm: nM=0,75nN.'],['Công thức hình thang in chia 0,5','Dùng nhân 0,5; không khẳng định mọi ô bảng mẫu đều sai.'],['Khởi đầu tốc độ động cơ quá thấp, dễ gọi nhầm tăng tốc từ đứng yên','Chọn nmin=800 rpm và ghi rõ bỏ giai đoạn trượt ly hợp.'],['Công thức Ne cuối tr.140 sách có dấu chia không khớp (I-2)','Dùng phép nhân đa thức đúng theo sách tr.11, (I-2).']])
heading('11. Cách sử dụng bộ hồ sơ')
para('Bang_tinh_Nhom_2.xlsx có các trang Dau_vao, Thiet_ke, Dong_co, Luc_keo, Bieu_do_dong, Tang_toc, Cong_thuc_nguon và Hinh_anh. Các trang công thức sẽ tính lại khi mở bằng Excel. Tang_toc và Hinh_anh là bản kết quả cố định được đánh dấu rõ; thay tham số phải chạy lại Python để tái tạo chúng. Các biểu đồ động trong Excel lấy dữ liệu từ ô công thức, còn tám hình xuất bản thể hiện bộ tham số gốc.')
para('Để tính lại toàn bộ: chỉnh nhom2.json, cài requirements.txt, chạy python build_model.py nhom2.json ket_qua_moi. Đổi số cấp hộp số phải tái tạo workbook. Chương trình dừng nếu lịch chuyển số không phù hợp miền tốc độ hoặc mục tiêu tăng tốc không đạt được với j>0. Tệp kiem_tra.json lưu kết quả kiểm tra và sai số; CSV lưu lịch sử chuyển động chi tiết.')
para('Nguồn: (1) Nguyễn Hữu Cẩn và cộng sự, Lý thuyết ô tô máy kéo, bản in 2005 do người dùng cung cấp. (2) BTL Lý thuyết ô tô – Tính toán sức kéo ô tô Nhóm 1, tệp PDF người dùng cung cấp. (3) Ảnh đề BTL Nhóm 2 trong cuộc trao đổi. Chưa bổ sung thông số từ nhà sản xuất.')

# The detailed prose above is specific to the original assignment. A changed
# configuration gets a fully numeric report, so original constants never leak
# into the new design narrative.
if hashlib.sha256(json.dumps(C,sort_keys=True).encode()).hexdigest() != '1a2fb2c9b1541823b6d5ea7fa3656b2b65b8d716f1994f9aa05c03a0564ddede':
    blocks=[]
    heading('BÁO CÁO TÍNH LẠI — MÔ HÌNH SỨC KÉO Ô TÔ')
    para('Bộ tham số đã thay đổi so với đề Nhóm 2 gốc. Báo cáo này dùng các giá trị mới, thay cho phần diễn giải cố định của phương án gốc. Công thức và phương pháp giữ nguyên: diesel theo đa thức, cản lăn ghép hai miền, bám theo tải tĩnh cầu sau, tích phân các pha kéo và chuyển số riêng.')
    heading('1. Toàn bộ tham số đã sử dụng')
    table(['Tham số','Giá trị','Đơn vị'],[[k,number(v,6),units.get(k,'–')] for k,v in C.items()])
    heading('2. Kết quả thiết kế')
    table(['Đại lượng','Giá trị'],[[k,number(v,6)] for k,v in dvalues.items()])
    para('Đơn vị: m là kg; G, G1, G2, Pphi là N; vmax là m/s; rb là m; Nv và Nmax là kW; nM và nv là rpm; Mmax là N·m. Các tỷ số truyền không có đơn vị. Nv là công suất cần tại vận tốc mục tiêu. Nếu power_factor khác 1 thì điểm cân bằng tốc độ thực không còn được bảo đảm bằng vận tốc mục tiêu; phải khảo sát lại giao điểm lực kéo và lực cản.')
    heading('3. Các pha tăng tốc')
    para(f'Bắt đầu ở {number(vstart,4)} km/h; kết thúc ở {number(C["target_fraction"]*C["vmax_kmh"],4)} km/h. Chưa tính xuất phát bằng ly hợp trượt. Tổng thời gian {number(tend,6)} s; quãng đường {number(send,6)} m.')
    table(['Pha','v đầu km/h','v cuối km/h','Δt s','ΔS m'],[[f'{r["kind"]} {r["gear"]}',number(r['v0']),number(r['v1']),number(r['dt']),number(r['ds'])] for r in stages])
    heading('4. Đồ thị tính lại')
    for name,title,_ in figures:picture(name,title)
    heading('5. Công thức và nguồn')
    para('Cột nguồn dùng trang in: PDF sách = trang in +1; PDF bài mẫu = trang in +7. Ghi chú gắn với đề gốc trong danh mục chỉ dùng để đối chiếu; tham số của lần chạy này được liệt kê ở mục 1.')
    for row in formula_rows:para(f'Mẫu ({row[0]}), tr.{row[1]}; sách tr.{row[2]}.');eq(row[3])
    heading('6. Kiểm tra và sử dụng')
    para(f'Đối chiếu tích phân quadrature: t={number(tref,6)} s; S={number(sref,6)} m. Sai số tương đối hình thang: t={checks["relative_time_error"]:.8f}; S={checks["relative_distance_error"]:.8f}.')
    para('Bảng Excel có công thức động cho thiết kế, động cơ và lực kéo; trang Tang_toc và ảnh là bản kết quả cố định của lần chạy này. Tái tạo toàn bộ bằng Python khi sửa tham số. Mô hình chưa xét chuyển tải động, đặc tính lốp thực, xuất phát trượt ly hợp hoặc đặc tính điều tốc động cơ thương mại.')

md=[];doc=Document();doc.styles['Normal'].font.name='Arial';doc.styles['Normal'].font.size=Pt(10)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('DV',font));pdfmetrics.registerFont(TTFont('DVB',bold))
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='VN',fontName='DV',fontSize=9,leading=14,spaceAfter=8));styles.add(ParagraphStyle(name='VNH',fontName='DVB',fontSize=13,leading=18,spaceBefore=14,spaceAfter=10,keepWithNext=True));styles.add(ParagraphStyle(name='VNE',fontName='DV',fontSize=9,leading=14,backColor=colors.HexColor('#eaf3f7'),borderPadding=7,spaceBefore=5,spaceAfter=10));styles.add(ParagraphStyle(name='VNT',fontName='DV',fontSize=7.4,leading=10));styles.add(ParagraphStyle(name='VNC',fontName='DV',fontSize=8,leading=11,spaceAfter=10))
story=[]
P=lambda s,style='VN':Paragraph(html.escape(str(s)),styles[style])
for kind,data in blocks:
    if kind=='h':md.append('## '+data);doc.add_heading(data,level=1);story.append(P(data,'VNH'))
    elif kind in ('p','e'):
        md.append(('> ' if kind=='e' else '')+data);doc.add_paragraph(data);story.append(P(data,'VNE' if kind=='e' else 'VN'))
    elif kind=='t':
        head,data_rows=data;md.append('| '+' | '.join(head)+' |\n| '+' | '.join(['---']*len(head))+' |\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in data_rows))
        dt=doc.add_table(rows=1,cols=len(head));dt.style='Light Shading Accent 1'
        for cell,value in zip(dt.rows[0].cells,head):cell.text=str(value)
        for row in data_rows:
            for cell,value in zip(dt.add_row().cells,row):cell.text=str(value)
        cols=len(head);widths=([110,115,270] if cols==3 else [190,305] if cols==2 else [495/cols]*cols)
        tab=Table([[P(x,'VNT') for x in head]]+[[P(x,'VNT') for x in row] for row in data_rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
        tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dbeef4')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#a9bdc4')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.extend([tab,Spacer(1,10)])
    elif kind=='img':
        name,caption=data;md.append(f'![{caption}](hinh/{name}.png)');doc.add_picture(str(FIG/(name+'.png')),width=Inches(6.1));doc.add_paragraph(caption)
        story.extend([Image(str(FIG/(name+'.png')),width=495,height=495*4.6/8),P(caption,'VNC')])
(OUT/'Thuyet_minh_Nhom_2.md').write_text('\n\n'.join(md),encoding='utf-8')
doc.save(OUT/'Thuyet_minh_Nhom_2.docx')
def footer(canvas,document):
    canvas.setFont('DV',8);canvas.setFillColor(colors.HexColor('#52616b'));canvas.drawString(50,25,'Lý thuyết ô tô • Nhóm 2 • Phương án tính toán theo giả thiết đã công bố');canvas.drawRightString(545,25,str(document.page))
SimpleDocTemplate(str(OUT/'Thuyet_minh_Nhom_2.pdf'),pagesize=(595.28,841.89),leftMargin=50,rightMargin=50,topMargin=42,bottomMargin=45,title='Bài tập lớn Lý thuyết ô tô – Nhóm 2',author='Bài tính từ dữ liệu đề Nhóm 2').build(story,onFirstPage=footer,onLaterPages=footer)
for _,_,fig in figures:plt.close(fig)
print(json.dumps(checks,ensure_ascii=False,indent=2))
