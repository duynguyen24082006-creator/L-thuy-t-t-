# Bài tập lớn Lý thuyết ô tô – Nhóm 2

Đề: xe tải, m0 = 3.450 kg, tải hàng 4.100 kg, 2 người, phân bố cầu 0,3/0,7, vận tốc 95 km/h, ψmax = 0,31, diesel, truyền lực cơ khí.

## Hồ sơ

- `ket_qua_nhom2/Thuyet_minh_Nhom_2.pdf`: thuyết minh 13 trang, có công thức, nguồn, giả thiết, bảng kết quả và hình.
- `ket_qua_nhom2/Thuyet_minh_Nhom_2.docx`: bản Word để chỉnh sửa.
- `ket_qua_nhom2/Bang_tinh_Nhom_2.xlsx`: đầu vào, thiết kế, đặc tính động cơ, lực kéo, nguồn công thức, đồ thị và kết quả tích phân.
- `ket_qua_nhom2/08_do_thi_A4.pdf`: tám bản vẽ A4 ngang.
- `ket_qua_nhom2/hinh/`: từng hình PNG và PDF.
- `ket_qua_nhom2/tang_toc_chi_tiet.csv`: các pha kéo và chuyển số, đơn vị SI.
- `ket_qua_nhom2/kiem_tra.json`: sai số cân bằng công suất và kiểm tra tích phân.

## Tái lập

Python 3.10 trở lên:

```bash
python -m pip install -r requirements.txt
python build_model.py nhom2.json ket_qua_nhom2
```

Để thay tham số, sao chép và chỉnh tệp JSON rồi chọn thư mục kết quả mới:

```bash
python build_model.py tham_so_moi.json ket_qua_moi
```

Khi tham số thay đổi, chương trình xuất báo cáo số liệu cập nhật thay cho phần diễn giải riêng của đề gốc. Mô hình vẫn dùng cùng giả thiết vật lý: cầu sau chủ động, đường bằng khi tăng tốc, không gió, cản lăn hai miền và bán kính lăn không đổi. Không dùng mô hình này thay cho mô phỏng tiếp xúc lốp–đất biến dạng.

## Lưu ý về Excel

Các trang `Thiet_ke`, `Dong_co`, `Luc_keo`, `Bieu_do_dong` có công thức/đồ thị tính lại khi sửa đầu vào. `Tang_toc` và `Hinh_anh` là kết quả cố định của lần chạy Python; chúng được đánh dấu trong workbook và không tự tính lại khi sửa Excel. Muốn tái tạo mọi kết quả, sửa JSON và chạy lại chương trình. Số cấp hộp số được cố định theo lần tạo workbook; đổi số cấp phải chạy lại Python.

Workbook có giá trị tính sẵn cho từng công thức. Đã kiểm tra công thức và giá trị lưu bằng openpyxl; chưa chạy Microsoft Excel hay LibreOffice trong môi trường này.

## Phạm vi kết quả gốc

- Mỗi người 70 kg; g = 9,81 m/s².
- Công suất cực đại thiết kế tối thiểu 117,011912 kW, chưa chọn động cơ thương mại. Động cơ có dự trữ lớn hơn cần được tính lại với đặc tính tương ứng.
- Tăng tốc từ 4,639805 đến 90,25 km/h, chưa tính xuất phát bằng ly hợp trượt: khoảng 108,898 s và 2.048,794 m, kể cả bốn lần chuyển số 1 s.
- Không tính đến đúng 95 km/h vì j tiến về 0 tại điểm cân bằng công suất.
- Mô hình cản lăn ghép theo tr.53 giáo trình có bước nhảy tại 22,2 m/s; tích phân đã tách miền tại đó. Bước nhảy là hạn chế của xấp xỉ, không phải hiện tượng lực thực tế đột ngột thay đổi.
- Kích thước lốp, diện tích cản, hiệu suất, tốc độ động cơ, hệ số bám và lịch chuyển số là thông số tự chọn được công bố trong thuyết minh.

Nguồn công thức được đối chiếu theo trang in của giáo trình Nguyễn Hữu Cẩn và bài mẫu Nhóm 1 do người dùng cung cấp. Các PDF nguồn không được đóng gói lại.
